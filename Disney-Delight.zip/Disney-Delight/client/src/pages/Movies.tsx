import { useMovies } from "@/hooks/use-content";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ContentCard } from "@/components/ContentCard";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import { useState } from "react";

export default function Movies() {
  const { data: movies, isLoading, error } = useMovies();
  const [search, setSearch] = useState("");

  const filteredMovies = movies?.filter(movie => 
    movie.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-12 pb-24">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-12">
            <div>
              <motion.h1 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-5xl md:text-6xl font-display font-bold mb-4"
              >
                Magical <span className="text-gradient">Movies</span>
              </motion.h1>
              <p className="text-muted-foreground text-lg max-w-xl">
                Timeless tales and unforgettable adventures that capture our hearts and imaginations.
              </p>
            </div>

            <div className="relative w-full md:w-auto min-w-[300px]">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <input 
                type="text"
                placeholder="Find a movie..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-12 pr-6 py-4 rounded-2xl bg-white/5 border border-white/10 text-white placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-[400px] rounded-2xl bg-white/5 animate-pulse" />
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-20">
              <p className="text-destructive text-xl">Something went wrong fetching the magic.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredMovies?.map((movie) => (
                <ContentCard
                  key={movie.id}
                  type="movie"
                  title={movie.title}
                  description={movie.description}
                  imageUrl={movie.imageUrl}
                  subtitle={movie.releaseYear.toString()}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
