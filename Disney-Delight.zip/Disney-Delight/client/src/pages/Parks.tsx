import { useParks } from "@/hooks/use-content";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ContentCard } from "@/components/ContentCard";
import { motion } from "framer-motion";

export default function Parks() {
  const { data: parks, isLoading, error } = useParks();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-12 pb-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-7xl font-display font-bold mb-6"
            >
              Destinations of <span className="text-gradient">Wonder</span>
            </motion.h1>
            <p className="text-muted-foreground text-xl max-w-2xl mx-auto">
              Explore the happiest places on Earth, where fantasy becomes reality and every corner holds a new surprise.
            </p>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {[...Array(2)].map((_, i) => (
                <div key={i} className="h-[500px] rounded-2xl bg-white/5 animate-pulse" />
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-20">
              <p className="text-destructive text-xl">Something went wrong fetching the magic.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {parks?.map((park) => (
                <ContentCard
                  key={park.id}
                  type="park"
                  title={park.name}
                  description={park.description}
                  imageUrl={park.imageUrl}
                  subtitle={park.location}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
