import { useCharacters } from "@/hooks/use-content";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ContentCard } from "@/components/ContentCard";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import { useState } from "react";

export default function Characters() {
  const { data: characters, isLoading, error } = useCharacters();
  const [search, setSearch] = useState("");

  const filteredCharacters = characters?.filter(char => 
    char.name.toLowerCase().includes(search.toLowerCase()) ||
    char.movieSource?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-12 pb-24">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-12">
            <div>
              <motion.h1 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-5xl md:text-6xl font-display font-bold mb-4"
              >
                Meet the <span className="text-gradient">Characters</span>
              </motion.h1>
              <p className="text-muted-foreground text-lg max-w-xl">
                From brave heroes to lovable sidekicks, discover the personalities that bring magic to life.
              </p>
            </div>

            <div className="relative w-full md:w-auto min-w-[300px]">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <input 
                type="text"
                placeholder="Find a character..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-12 pr-6 py-4 rounded-2xl bg-white/5 border border-white/10 text-white placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-[400px] rounded-2xl bg-white/5 animate-pulse" />
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-20">
              <p className="text-destructive text-xl">Something went wrong fetching the magic.</p>
            </div>
          ) : (
            <>
              {filteredCharacters?.length === 0 ? (
                <div className="text-center py-20 opacity-50">
                  <p className="text-2xl font-display">No characters found...</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                  {filteredCharacters?.map((char) => (
                    <ContentCard
                      key={char.id}
                      type="character"
                      title={char.name}
                      description={char.description}
                      imageUrl={char.imageUrl}
                      subtitle={char.movieSource || undefined}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
