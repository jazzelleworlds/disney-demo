import { Link } from "wouter";
import { motion } from "framer-motion";
import { Sparkles, Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4 relative overflow-hidden">
      {/* Background Magic */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-background to-background" />
      
      <div className="relative z-10 text-center max-w-md mx-auto">
        <motion.div
          initial={{ rotate: -10, opacity: 0 }}
          animate={{ rotate: 10, opacity: 1 }}
          transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
          className="mb-8 inline-block"
        >
          <Sparkles className="w-24 h-24 text-primary" />
        </motion.div>
        
        <h1 className="text-6xl md:text-8xl font-display font-bold text-white mb-6">
          404
        </h1>
        
        <h2 className="text-2xl font-bold text-white mb-4">
          Lost in the Magic?
        </h2>
        
        <p className="text-muted-foreground mb-8 text-lg">
          The page you are looking for seems to have vanished into thin air like pixie dust.
        </p>
        
        <Link href="/">
          <button className="px-8 py-4 rounded-full bg-primary text-primary-foreground font-bold text-lg hover:scale-105 transition-transform shadow-lg shadow-primary/25 flex items-center gap-2 mx-auto">
            <Home className="w-5 h-5" />
            Return Home
          </button>
        </Link>
      </div>
    </div>
  );
}
