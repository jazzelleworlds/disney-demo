import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Star, Clapperboard, Map } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/60 to-background z-10" />
          {/* castle magic fireworks */}
          <img 
            src="https://pixabay.com/get/gac8596b070bb7aa8105b51cbe62ed7f6da5387e45de1b94eae255fa68486fb676ac4da2a33b4cb9106b607a234b95839ddea4ce3202b67e0f80a0d1032e57a7d_1280.jpg" 
            alt="Magic Kingdom Castle" 
            className="w-full h-full object-cover"
          />
        </div>

        <div className="container relative z-20 px-4 text-center">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, type: "spring" }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-8"
          >
            <Star className="w-4 h-4 text-primary fill-primary" />
            <span className="text-sm font-semibold tracking-wider uppercase text-white">Welcome to the Magic</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-6xl md:text-8xl font-display font-bold mb-6 text-white drop-shadow-2xl"
          >
            Where Dreams <br />
            <span className="text-gradient">Come True</span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="max-w-2xl mx-auto text-xl md:text-2xl text-white/80 mb-12 font-light leading-relaxed"
          >
            Explore the enchanting world of your favorite characters, timeless movies, and magical destinations.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link href="/characters">
              <button className="px-8 py-4 rounded-full bg-primary text-primary-foreground font-bold text-lg hover:scale-105 transition-transform shadow-lg shadow-primary/25 flex items-center gap-2 justify-center">
                Explore Characters
                <ArrowRight className="w-5 h-5" />
              </button>
            </Link>
            <Link href="/parks">
              <button className="px-8 py-4 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white font-bold text-lg hover:bg-white/20 transition-colors flex items-center gap-2 justify-center">
                Visit Parks
              </button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-32 relative z-10">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <CategoryCard 
              to="/characters"
              icon={<Star className="w-8 h-8" />}
              title="Characters"
              description="Meet the heroes, villains, and friends that make the magic happen."
              delay={0.1}
            />
            <CategoryCard 
              to="/movies"
              icon={<Clapperboard className="w-8 h-8" />}
              title="Movies"
              description="Relive the classics and discover new favorites from our collection."
              delay={0.2}
            />
            <CategoryCard 
              to="/parks"
              icon={<Map className="w-8 h-8" />}
              title="Parks"
              description="Plan your visit to the happiest places on Earth."
              delay={0.3}
            />
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function CategoryCard({ to, icon, title, description, delay }: { to: string, icon: any, title: string, description: string, delay: number }) {
  return (
    <Link href={to} className="block group cursor-pointer">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay }}
        className="glass-card p-8 rounded-3xl h-full border border-white/5 hover:border-primary/50 transition-colors relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 p-32 bg-primary/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-primary/10 transition-colors" />
        
        <div className="relative z-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-white/10 to-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 border border-white/10 group-hover:border-primary/50 text-white group-hover:text-primary shadow-lg">
            {icon}
          </div>
          
          <h3 className="text-3xl font-display font-bold mb-3 text-white group-hover:text-primary transition-colors">
            {title}
          </h3>
          
          <p className="text-muted-foreground leading-relaxed mb-6 group-hover:text-white/80 transition-colors">
            {description}
          </p>

          <div className="flex items-center gap-2 text-primary font-bold text-sm uppercase tracking-widest opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
            Discover
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
