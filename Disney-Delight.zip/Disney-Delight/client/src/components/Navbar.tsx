import { Link, useLocation } from "wouter";
import { Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export function Navbar() {
  const [location] = useLocation();

  const links = [
    { href: "/", label: "Home" },
    { href: "/characters", label: "Characters" },
    { href: "/movies", label: "Movies" },
    { href: "/parks", label: "Parks" },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group cursor-pointer">
          <div className="relative">
            <Sparkles className="w-8 h-8 text-primary transition-transform group-hover:rotate-12" />
            <div className="absolute inset-0 blur-lg bg-primary/40 opacity-50 group-hover:opacity-100 transition-opacity" />
          </div>
          <span className="text-2xl font-bold font-display tracking-wide text-foreground">
            Disney<span className="text-primary">Magic</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          {links.map((link) => {
            const isActive = location === link.href;
            return (
              <Link key={link.href} href={link.href} className="relative py-2 group cursor-pointer">
                <span className={`text-sm font-semibold tracking-wide transition-colors ${
                  isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
                }`}>
                  {link.label}
                </span>
                {isActive && (
                  <motion.div
                    layoutId="navbar-indicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary shadow-[0_0_10px_rgba(234,179,8,0.5)]"
                  />
                )}
              </Link>
            );
          })}
        </div>

        {/* Mobile menu trigger could go here */}
      </div>
    </nav>
  );
}
