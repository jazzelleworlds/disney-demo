import { motion } from "framer-motion";
import { Star, MapPin, Calendar } from "lucide-react";

interface ContentCardProps {
  title: string;
  description: string;
  imageUrl: string;
  subtitle?: string;
  type: "character" | "movie" | "park";
}

export function ContentCard({ title, description, imageUrl, subtitle, type }: ContentCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group relative flex flex-col h-full overflow-hidden rounded-2xl glass-card hover-lift cursor-default"
    >
      <div className="relative aspect-[3/4] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent z-10 opacity-60 group-hover:opacity-40 transition-opacity" />
        <img 
          src={imageUrl || "https://placehold.co/600x800?text=Magic"} 
          alt={title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        
        {/* Type Badge */}
        <div className="absolute top-4 right-4 z-20">
          <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-black/40 backdrop-blur-md border border-white/10 text-white">
            {type}
          </span>
        </div>
      </div>

      <div className="relative p-6 -mt-20 z-20 flex flex-col flex-grow bg-gradient-to-b from-transparent to-background/95">
        <div className="mb-2">
          {subtitle && (
            <div className="flex items-center gap-1.5 text-primary text-xs font-bold uppercase tracking-wider mb-1">
              {type === "character" && <Star className="w-3 h-3" />}
              {type === "movie" && <Calendar className="w-3 h-3" />}
              {type === "park" && <MapPin className="w-3 h-3" />}
              {subtitle}
            </div>
          )}
          <h3 className="text-2xl font-bold font-display text-white group-hover:text-primary transition-colors">
            {title}
          </h3>
        </div>
        
        <p className="text-muted-foreground text-sm line-clamp-3 leading-relaxed">
          {description}
        </p>

        <div className="mt-auto pt-6 flex items-center justify-between">
          <button className="text-xs font-bold text-white uppercase tracking-widest hover:text-primary transition-colors">
            Learn More
          </button>
        </div>
      </div>
    </motion.div>
  );
}
