import { Sparkles } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-background/50 backdrop-blur-lg pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center justify-center text-center">
          <div className="mb-6 p-3 rounded-full bg-primary/10 border border-primary/20">
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
          <h2 className="text-2xl font-bold font-display mb-4">The Magic Awaits</h2>
          <p className="text-muted-foreground max-w-md mb-8">
            Experience the wonder of Disney stories, characters, and adventures all in one magical place.
          </p>
          
          <div className="flex items-center gap-6 mb-12">
            {['Terms', 'Privacy', 'Cookies', 'About'].map((item) => (
              <a key={item} href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                {item}
              </a>
            ))}
          </div>
          
          <div className="text-xs text-muted-foreground/50 font-mono">
            © {new Date().getFullYear()} Disney Magic Fan Site. Not affiliated with The Walt Disney Company.
          </div>
        </div>
      </div>
    </footer>
  );
}
