import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

// Characters Hooks
export function useCharacters() {
  return useQuery({
    queryKey: [api.characters.list.path],
    queryFn: async () => {
      const res = await fetch(api.characters.list.path);
      if (!res.ok) throw new Error("Failed to fetch characters");
      return api.characters.list.responses[200].parse(await res.json());
    },
  });
}

export function useCharacter(id: number) {
  return useQuery({
    queryKey: [api.characters.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.characters.get.path, { id });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch character");
      return api.characters.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

// Movies Hooks
export function useMovies() {
  return useQuery({
    queryKey: [api.movies.list.path],
    queryFn: async () => {
      const res = await fetch(api.movies.list.path);
      if (!res.ok) throw new Error("Failed to fetch movies");
      return api.movies.list.responses[200].parse(await res.json());
    },
  });
}

export function useMovie(id: number) {
  return useQuery({
    queryKey: [api.movies.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.movies.get.path, { id });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch movie");
      return api.movies.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

// Parks Hooks
export function useParks() {
  return useQuery({
    queryKey: [api.parks.list.path],
    queryFn: async () => {
      const res = await fetch(api.parks.list.path);
      if (!res.ok) throw new Error("Failed to fetch parks");
      return api.parks.list.responses[200].parse(await res.json());
    },
  });
}

export function usePark(id: number) {
  return useQuery({
    queryKey: [api.parks.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.parks.get.path, { id });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch park");
      return api.parks.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}
