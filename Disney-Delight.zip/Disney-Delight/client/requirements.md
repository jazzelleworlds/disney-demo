## Packages
framer-motion | Complex animations and page transitions
react-icons | Additional magical icons if needed (optional, using Lucide primarily)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Architects Daughter'", "cursive"],
  body: ["'DM Sans'", "sans-serif"],
  magical: ["'Playfair Display'", "serif"],
}
