import { db } from "./db";
import {
  characters, movies, parks,
  type Character, type InsertCharacter,
  type Movie, type InsertMovie,
  type Park, type InsertPark
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Characters
  getCharacters(): Promise<Character[]>;
  getCharacter(id: number): Promise<Character | undefined>;
  createCharacter(character: InsertCharacter): Promise<Character>;

  // Movies
  getMovies(): Promise<Movie[]>;
  getMovie(id: number): Promise<Movie | undefined>;
  createMovie(movie: InsertMovie): Promise<Movie>;

  // Parks
  getParks(): Promise<Park[]>;
  getPark(id: number): Promise<Park | undefined>;
  createPark(park: InsertPark): Promise<Park>;
}

export class DatabaseStorage implements IStorage {
  // Characters
  async getCharacters(): Promise<Character[]> {
    return await db.select().from(characters);
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    const [character] = await db.select().from(characters).where(eq(characters.id, id));
    return character;
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const [character] = await db.insert(characters).values(insertCharacter).returning();
    return character;
  }

  // Movies
  async getMovies(): Promise<Movie[]> {
    return await db.select().from(movies);
  }

  async getMovie(id: number): Promise<Movie | undefined> {
    const [movie] = await db.select().from(movies).where(eq(movies.id, id));
    return movie;
  }

  async createMovie(insertMovie: InsertMovie): Promise<Movie> {
    const [movie] = await db.insert(movies).values(insertMovie).returning();
    return movie;
  }

  // Parks
  async getParks(): Promise<Park[]> {
    return await db.select().from(parks);
  }

  async getPark(id: number): Promise<Park | undefined> {
    const [park] = await db.select().from(parks).where(eq(parks.id, id));
    return park;
  }

  async createPark(insertPark: InsertPark): Promise<Park> {
    const [park] = await db.insert(parks).values(insertPark).returning();
    return park;
  }
}

export const storage = new DatabaseStorage();
