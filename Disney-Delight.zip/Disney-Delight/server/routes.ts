import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

async function seedDatabase() {
  const existingCharacters = await storage.getCharacters();
  if (existingCharacters.length === 0) {
    await storage.createCharacter({
      name: "Mickey Mouse",
      description: "The classic mouse who started it all.",
      imageUrl: "https://images.unsplash.com/photo-1525316315865-c7e6c5180cb9?auto=format&fit=crop&q=80&w=1000",
      movieSource: "Steamboat Willie"
    });
    await storage.createCharacter({
      name: "Elsa",
      description: "The Snow Queen with magical ice powers.",
      imageUrl: "https://images.unsplash.com/photo-1563249767-4315fbf80e60?auto=format&fit=crop&q=80&w=1000",
      movieSource: "Frozen"
    });
    await storage.createCharacter({
      name: "Simba",
      description: "The future king of the Pride Lands.",
      imageUrl: "https://images.unsplash.com/photo-1601053424653-e5746b0ce208?auto=format&fit=crop&q=80&w=1000",
      movieSource: "The Lion King"
    });
  }

  const existingMovies = await storage.getMovies();
  if (existingMovies.length === 0) {
    await storage.createMovie({
      title: "The Lion King",
      description: "Lion prince Simba and his father are targeted by his bitter uncle, who wants to ascend the throne himself.",
      releaseYear: 1994,
      imageUrl: "https://images.unsplash.com/photo-1544402636-6e5a62f8386c?auto=format&fit=crop&q=80&w=1000"
    });
    await storage.createMovie({
      title: "Frozen",
      description: "When the newly crowned Queen Elsa accidentally uses her power to turn things into ice to curse her home in infinite winter, her sister Anna teams up with a mountain man, his playful reindeer, and a snowman to change the weather condition.",
      releaseYear: 2013,
      imageUrl: "https://images.unsplash.com/photo-1605330364239-0cb8523c9522?auto=format&fit=crop&q=80&w=1000"
    });
    await storage.createMovie({
      title: "Aladdin",
      description: "A kindhearted street urchin and a power-hungry Grand Vizier vie for a magic lamp that has the power to make their deepest wishes come true.",
      releaseYear: 1992,
      imageUrl: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&q=80&w=1000"
    });
  }

  const existingParks = await storage.getParks();
  if (existingParks.length === 0) {
    await storage.createPark({
      name: "Magic Kingdom",
      location: "Orlando, Florida",
      description: "Fairytale dreams come true for children of all ages at Magic Kingdom park.",
      imageUrl: "https://images.unsplash.com/photo-1517743171891-b4f0b09335f6?auto=format&fit=crop&q=80&w=1000"
    });
    await storage.createPark({
      name: "Disneyland Paris",
      location: "Marne-la-Vallée, France",
      description: "Experience the magic of Disney with a European twist.",
      imageUrl: "https://images.unsplash.com/photo-1596207106096-7b2432ae3858?auto=format&fit=crop&q=80&w=1000"
    });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Characters
  app.get(api.characters.list.path, async (req, res) => {
    const characters = await storage.getCharacters();
    res.json(characters);
  });

  app.get(api.characters.get.path, async (req, res) => {
    const character = await storage.getCharacter(Number(req.params.id));
    if (!character) {
      return res.status(404).json({ message: "Character not found" });
    }
    res.json(character);
  });

  // Movies
  app.get(api.movies.list.path, async (req, res) => {
    const movies = await storage.getMovies();
    res.json(movies);
  });

  app.get(api.movies.get.path, async (req, res) => {
    const movie = await storage.getMovie(Number(req.params.id));
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" });
    }
    res.json(movie);
  });

  // Parks
  app.get(api.parks.list.path, async (req, res) => {
    const parks = await storage.getParks();
    res.json(parks);
  });

  app.get(api.parks.get.path, async (req, res) => {
    const park = await storage.getPark(Number(req.params.id));
    if (!park) {
      return res.status(404).json({ message: "Park not found" });
    }
    res.json(park);
  });

  // Seed data on startup
  seedDatabase().catch(console.error);

  return httpServer;
}
