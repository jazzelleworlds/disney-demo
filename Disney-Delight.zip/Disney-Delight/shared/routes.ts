import { z } from 'zod';
import { insertCharacterSchema, insertMovieSchema, insertParkSchema, characters, movies, parks } from './schema';

export const api = {
  characters: {
    list: {
      method: 'GET' as const,
      path: '/api/characters',
      responses: {
        200: z.array(z.custom<typeof characters.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/characters/:id',
      responses: {
        200: z.custom<typeof characters.$inferSelect>(),
        404: z.object({ message: z.string() }),
      },
    },
  },
  movies: {
    list: {
      method: 'GET' as const,
      path: '/api/movies',
      responses: {
        200: z.array(z.custom<typeof movies.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/movies/:id',
      responses: {
        200: z.custom<typeof movies.$inferSelect>(),
        404: z.object({ message: z.string() }),
      },
    },
  },
  parks: {
    list: {
      method: 'GET' as const,
      path: '/api/parks',
      responses: {
        200: z.array(z.custom<typeof parks.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/parks/:id',
      responses: {
        200: z.custom<typeof parks.$inferSelect>(),
        404: z.object({ message: z.string() }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
